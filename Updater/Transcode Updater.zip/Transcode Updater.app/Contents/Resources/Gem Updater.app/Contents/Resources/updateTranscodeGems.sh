#!/bin/sh

# PATH=/bin:/usr/bin:/sbin:/usr/sbin:/usr/local/bin export PATH  #----- DO NOT INCLUDE PATH CHANGES, OTHERWISE WILL NOT FUNCTION!!! -------

# set -xv; exec 1>>/tmp/updateTranscodeGemsTraceLog 2>&1

#-----------------------------------------------------------------------------------------------------------------------------------																		
#	updateTranscodeGems
#	Copyright (c) 2016-2017 Brent Hayward		
#
#	
#	This script is called from Transcode Updater.app to see if Ruby Gems need to be udpated and logs the results to the system log
#	This script needs to be placed in Transcode_Update.app/Content/Resources
#


#----------------------------------------------------------FUNCTIONS----------------------------------------------------------------

function define_Constants () {
	local versStamp="Version 1.2.0, 03-24-2017"
	
	loggerTag="gem.update"
	
	readonly LIBDIR="${HOME}/Library"
	
	readonly APPSCRIPTSPATH="/usr/local/Transcode"
	readonly LIBSCRIPTSPATH="${APPSCRIPTSPATH}/Library"
	readonly ICNSPATH="${LIBDIR}/Application Support/Transcode/Transcode_custom.icns"
	
	readonly PLISTBUDDY="/usr/libexec/PlistBuddy"
	readonly SH_ECHOMSG="${LIBSCRIPTSPATH}/_echoMsg.sh"
	readonly SH_IFERROR="${LIBSCRIPTSPATH}/_ifError.sh"
	
	msgTxt="All up-to-date!"
}

function updateGems () {
	local plistName=""
	local plistDir=""
	local plistFile=""
	
	plistName="com.videotranscode.gem.update"
	plistDir="/tmp"
	plistFile="${plistDir}/${plistName}.plist"
	
	. "${SH_ECHOMSG}" "Checking updates..." ""
	
	vtVers=$(${PLISTBUDDY} -c 'print :video_transcoding' "${plistFile}")
																							# delete the info plist
	/bin/rm -f "${plistFile}"

	if [[ "${vtVers}" != "0" ]]; then
		msgTxt="Transcode successfully updated"
																							# update the gems
		if [[ "${vtVers}" != "0" ]]; then
																							# upgrade video_transcoding
			. "${SH_ECHOMSG}" "Updating video_transcoding gem..." ""
			
			gem update video_transcoding 2>&1 | logger -t "${loggerTag}"
			gem cleanup video_transcoding 2>&1 | logger -t "${loggerTag}"
			
			msgTxt="${msgTxt} video_transcoding gem to version ${vtVers}"
		fi
	fi
}

function clean_Up () {
																							# remove the semaphore files
	/bin/rm -f "${LIBDIR}/Preferences/com.videotranscode.gem.update.inprogress.plist"
}

function __main__ () {
	define_Constants

	updateGems

/bin/cat << EOF | /usr/bin/osascript -l AppleScript > /dev/null
set iconPath to "$ICNSPATH" as string
set posixPath to POSIX path of iconPath
set hfsPath to POSIX file posixPath

display dialog "$msgTxt" buttons {"OK"} default button "OK" with title "Transcode" with icon file hfsPath
EOF
}


#----------------------------------------------------------MAIN----------------------------------------------------------------
																							# Execute
trap clean_Up INT TERM EXIT																	# always run clean_Up regardless of how the script terminates																									
trap '. "${SH_IFERROR}" ${LINENO} $?' ERR													# trap errors

__main__

exit 0
#!/bin/sh

PATH=/bin:/usr/bin:/sbin:/usr/sbin:/usr/local/bin export PATH

# set -xv; exec 1>>/tmp/updateTranscodePostTraceLog 2>&1

#-----------------------------------------------------------------------------------------------------------------------------------																		
#	updateTranscodePost		
#	Copyright (c) 2016 Brent Hayward		
#
#
#	This script runs after updateTranscode as a mechanism to update items outside of updateTranscodes responsbilities
#


#----------------------------------------------------------FUNCTIONS----------------------------------------------------------------

function define_Constants () {
	local versStamp="Version 1.0.1, 05-28-2016"
	
	loggerTag="transcode.post-update"
	
	readonly libDir="${HOME}/Library"
	readonly workDir=$(aliasPath "${libDir}/Application Support/Transcode/Transcode alias")
	
	readonly appScriptsPath="${libDir}/Application Scripts/com.videotranscode.transcode"
	readonly updateTranscode="/tmp/updateTranscode.sh"
	
	readonly sh_ifError="${appScriptsPath}/_ifError.sh"
}

function clean_Up () {
																							# make sure all scripts are executable
	find "${appScriptsPath}/" -name "*.sh" -exec chmod +x {} \;
	find "${workDir}/" -name "*.command" -exec chmod +x {} \;
	find "${workDir}/Extras/" -name "*.command" -exec chmod +x {} \;
}

function __main__ () {
	define_Constants
																							# does updateTranscode.sh need to be updated?
	if [ -e "${updateTranscode}" ]; then
		ditto "${updateTranscode}" "${appScriptsPath}"
																							# remove from /tmp
		rm -f "${updateTranscode}"
	fi
	
	# add any additional update specific code here
}


#----------------------------------------------------------MAIN----------------------------------------------------------------
																							# Execute
trap clean_Up INT TERM EXIT																	# always run clean_Up regardless of how the script terminates
trap '. "${sh_ifError}" ${LINENO} $?' ERR													# trap errors

__main__

exit 0
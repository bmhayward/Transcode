#!/usr/bin/env bash

PATH=/bin:/usr/bin:/sbin:/usr/sbin:/usr/local/bin:/usr/local/Transcode:/usr/local/Transcode/Library export PATH		# export PATH to Transcode libraries

# set -xv; exec 1>>/tmp/transcodeSetupTraceLog 2>&1

#-----------------------------------------------------------------------------------------------------------------------------------																		
#	transcodeSetup
#	Copyright (c) 2016-2017 Brent Hayward
#		
#	
#	This script installs everything required to transcode video using the batch.sh script
#


#----------------------------------------------------------FUNCTIONS----------------------------------------------------------------

function define_Constants () {
	local versStamp="Version 1.6.1, 03-30-2017"
	
	loggerTag="transcode.install"

	readonly LIBDIR="${HOME}/Library"
	readonly PLISTDIR="${LIBDIR}/LaunchAgents"
	readonly LBIN="/usr/local/bin/"
	readonly SCRIPTSDIR="/usr/local/Transcode"
	readonly TRANSCODELIB="${SCRIPTSDIR}/Library"
	readonly SUPPORTDIR="${LIBDIR}/Application Support"
	readonly PLISTBUDDY="/usr/libexec/PlistBuddy"
																							# get the paths
	local DIR=""
	local SOURCE="${BASH_SOURCE[0]}"
	
	while [[ -h "${SOURCE}" ]]; do 															# resolve ${SOURCE} until the file is no longer a symlink
		DIR="$( cd -P "$( dirname "${SOURCE}" )" && pwd )"
		SOURCE="$(readlink "${SOURCE}")"
		[[ ${SOURCE} != /* ]] && SOURCE="${DIR}/${SOURCE}" 									# if ${SOURCE} was a relative symlink, we need to resolve it relative to the path where the symlink file was located
	done
	
	readonly SCRIPTPATH="$( cd -P "$( dirname "${SOURCE}" )" && pwd )"
	
	xcodeInstall="false"
}

function install_Scripts () {
	local fileName=""
	local scriptName=""
																							# add the /Transcode infrastructure to /usr/local
	if [[ ! -d "${SCRIPTSDIR}" ]]; then
		sudo mkdir -p "${SCRIPTSDIR}"
		sudo chown "${USER}" "${SCRIPTSDIR}"
		sudo chgrp admin "${SCRIPTSDIR}"

		mkdir -p "${SCRIPTSDIR}/Library"
	fi
	
	fileName="vtScripts.zip"
	
	ditto "/tmp/${fileName}" "${SCRIPTSDIR}"
	
	cd "${SCRIPTSDIR}" || return
	unzip -uo "${SCRIPTSDIR}/${fileName}"
																							# remove the remnants of the unzipping process
	rm -f "${SCRIPTSDIR}/${fileName}"
	rm -rf "${SCRIPTSDIR}/__MACOSX"

	chmod +x "${SCRIPTSDIR}/"*.sh
																							# move all library scripts to /usr/local/Transcode
	declare -a filePath

	filePath=( "${SCRIPTSDIR}"/* )															# filename with path

	for i in "${filePath[@]}"; do
		scriptName="${i##*/}"

		if [[ "${scriptName}" == _* ]]; then
			ditto "${i}" "${SCRIPTSDIR}/Library/${scriptName}"
			rm -f "${i}"
		fi
	done
																							# need to rename the Transcode alias file
	if [[ -e "${SUPPORTDIR}/Transcode/Transcode" ]]; then
		mv "${SUPPORTDIR}/Transcode/Transcode" "${SUPPORTDIR}/Transcode/Transcode alias"
	fi
																							# need to rename the Logs alias file
	if [[ -e "${SUPPORTDIR}/Transcode/Logs" ]]; then
		mv "${SUPPORTDIR}/Transcode/Logs" "${SUPPORTDIR}/Transcode/Logs alias"
	fi
}

function install_Tools () {
	local binPermissions=""
	local binUser=""
	local binGroup=""
																							# Ruby - exit if not installed
	if ! command -v ruby > /dev/null; then
		. "_echoMsg.sh" "Ruby 2.0 or later is required to complete installation.\nPlease install the latest version of OS X."
		exit 1
	fi
	
	. "_echoMsg.sh" ""
																							# XCode command-line tools - install if not in place
	if [[ ! -d "/Library/Developer/CommandLineTools" && ! -d "/Applications/Xcode.app/Contents/Developer" ]]; then
		xcodeInstall="true"
		
		xcode-select --install
	else
		. "_echoMsg.sh" "Xcode Tools already installed"
	fi
																							# /local/bin - create if not in place, brew should have done this already
	if [[ ! -d "${LBIN}" ]]; then
		. "_echoMsg.sh" "Creating ${LBIN}"
		
		mkdir -p "${LBIN}"
	fi
																							# make sure permissions are correct
	binPermissions=$(ls -ld ${LBIN} | awk '{print $1}')
	binUser=$(ls -ld ${LBIN} | awk '{print $3}')
	binGroup=$(ls -ld ${LBIN} | awk '{print $4}')
	
	if [[ "${binUser}" != "${USER}" || "${binGroup}" != "admin" ]]; then
		. "_echoMsg.sh" "${LBIN} owner:group need to be updated:"
		sudo chown "${USER}:admin" "${LBIN}"
	fi
	
	if [[ "${binPermissions}" != "drwxrwxr-x" ]]; then
		. "_echoMsg.sh" "${LBIN} permissions need to be updated:"
		sudo chmod 0775 "${LBIN}"
	fi
}

function create_Plists () {
	local transcodePath=""
	local watchPath=""
	
	transcodePath=$(. "_aliasPath.sh" "${SUPPORTDIR}/Transcode/Transcode alias")
	
	. "_echoMsg.sh" ""
																													# create the launchAgent directory if it does not exist
	if [[ ! -d "${PLISTDIR}" ]]; then
	  mkdir -p "${PLISTDIR}"
	fi
	
	declare -a plistName_a
	
	plistName_a[0]="com.videotranscode.brewautoupdate"
	plistName_a[1]="com.videotranscode.watchfolder"
	plistName_a[2]="com.videotranscode.gem.check"
	plistName_a[3]="com.videotranscode.watchfolders.moved"
		
	plistFile="${PLISTDIR}/${plistName_a[0]}.plist"

	if [[ ! -e "${plistFile}" ]]; then 																				# write out the auto-update LaunchAgent plist to ~/Library/LaunchAgent
		${PLISTBUDDY} -c 'Add :Label string "'"${plistName_a[0]}"'"' "${plistFile}"; cat "${plistFile}" > /dev/null 2>&1
		${PLISTBUDDY} -c 'Add :ProgramArguments array' "${plistFile}"
		${PLISTBUDDY} -c 'Add :ProgramArguments:0 string "'"${SCRIPTSDIR}/brewAutoUpdate.sh"'"' "${plistFile}"
		${PLISTBUDDY} -c 'Add :RunAtLoad bool false' "${plistFile}"
		${PLISTBUDDY} -c 'Add :StartCalendarInterval array' "${plistFile}"
		${PLISTBUDDY} -c 'Add :StartCalendarInterval:0 dict' "${plistFile}"
		${PLISTBUDDY} -c 'Add :StartCalendarInterval:0:Hour integer 3' "${plistFile}"
		${PLISTBUDDY} -c 'Add :StartCalendarInterval:0:Minute integer 0' "${plistFile}"

		chmod 644 "${plistFile}"
		
		launchctl load -w "${plistFile}" 2>&1 | logger -t "${loggerTag}"											# load the launchAgent
	fi

	plistFile="${PLISTDIR}/${plistName_a[1]}.plist"																	# get the watch folder launch agent

	if [[ ! -e "${plistFile}" ]]; then																				# write out the watch folder LaunchAgent plist to ~/Library/LaunchAgent
		watchPath="${transcodePath}/Convert"																		# get the path to /Transcode/Convert from the alias left behind by Video Transcode Setup Assistant

		${PLISTBUDDY} -c 'Add :Label string "'"${plistName_a[1]}"'"' "${plistFile}"; cat "${plistFile}" > /dev/null 2>&1
		${PLISTBUDDY} -c 'Add :ProgramArguments array' "${plistFile}"
		${PLISTBUDDY} -c 'Add :ProgramArguments:0 string "'"${SCRIPTSDIR}/watchFolder.sh"'"' "${plistFile}"
		${PLISTBUDDY} -c 'Add :RunAtLoad bool true' "${plistFile}"
		${PLISTBUDDY} -c 'Add :WatchPaths array' "${plistFile}"
		${PLISTBUDDY} -c 'Add :WatchPaths:0 string "'"${watchPath}"'"' "${plistFile}"

		chmod 644 "${plistFile}"
		
		launchctl load -w "${plistFile}" 2>&1 | logger -t "${loggerTag}"											# load the launchAgent
	fi
	
	plistFile="${PLISTDIR}/${plistName_a[2]}.plist"																	# get the watch folder launch agent

	if [[ ! -e "${plistFile}" ]]; then																				# write out the watch folder LaunchAgent plist to ~/Library/LaunchAgent
		${PLISTBUDDY} -c 'Add :Label string "'"${plistName_a[2]}"'"' "${plistFile}"; cat "${plistFile}" > /dev/null 2>&1
		${PLISTBUDDY} -c 'Add :EnvironmentVariables dict' "${plistFile}"
		${PLISTBUDDY} -c 'Add :EnvironmentVariables:PATH string /usr/local/bin:/usr/bin:/usr/sbin:/usr/local/Transcode' "${plistFile}"
		${PLISTBUDDY} -c 'Add :ProgramArguments array' "${plistFile}"
		${PLISTBUDDY} -c 'Add :ProgramArguments:0 string "'"${SCRIPTSDIR}/Transcode Updater.app/Contents/Resources/updateTranscodeGemsCheck.sh"'"' "${plistFile}"
		${PLISTBUDDY} -c 'Add :RunAtLoad bool false' "${plistFile}"
		${PLISTBUDDY} -c 'Add :StartCalendarInterval array' "${plistFile}"
		${PLISTBUDDY} -c 'Add :StartCalendarInterval:0:Hour integer 9' "${plistFile}"
		${PLISTBUDDY} -c 'Add :StartCalendarInterval:0:Minute integer 5' "${plistFile}"
        
		chmod 644 "${plistFile}"
		
		launchctl load -w "${plistFile}" 2>&1 | logger -t "${loggerTag}"											# load the launchAgent
	fi
	
	plistFile="${PLISTDIR}/${plistName_a[3]}.plist"																	# get the watch folder launch agent

	if [[ ! -e "${plistFile}" ]]; then																				# write out the watch folder LaunchAgent plist to ~/Library/LaunchAgent
		${PLISTBUDDY} -c 'Add :Label string "'"${plistName_a[3]}"'"' "${plistFile}"; cat "${plistFile}" > /dev/null 2>&1
		${PLISTBUDDY} -c 'Add :KeepAlive:PathState:"'"${transcodePath}"'" bool true' "${plistFile}"
		${PLISTBUDDY} -c 'Add :ProgramArguments array' "${plistFile}"
		${PLISTBUDDY} -c 'Add :ProgramArguments:0 string "'"${SCRIPTSDIR}/watchFolder_transcodeMoved.sh"'"' "${plistFile}"
		${PLISTBUDDY} -c 'Add :RunAtLoad bool true' "${plistFile}"

		chmod 644 "${plistFile}"
		
		launchctl load -w "${plistFile}" 2>&1 | logger -t "${loggerTag}"											# load the launchAgent	
	fi	
}

function uninstall_brewPkgs () {
	local installedBrews=""
	
	if hash brew 2>/dev/null; then
		. "_echoMsg.sh" ""
	
		declare -a removeThis_a
	
		removeThis_a[0]="atomicparsley"
		removeThis_a[1]="ffmpeg"
		removeThis_a[2]="mkvtoolnix"
		removeThis_a[3]="mp4v2"
		removeThis_a[4]="mplayer"
		removeThis_a[5]="rsync"
		removeThis_a[6]="tag"
		removeThis_a[7]="ssh-copy-id"
		removeThis_a[8]="terminal-notifier"
		removeThis_a[9]="handbrake"
	
	
		installedBrews=$(brew list)
																								# brew, remove if in place
		for i in "${removeThis_a[@]}"; do
			if [[ ${installedBrews} == *"${i}"* ]]; then
				. "_echoMsg.sh" "Removing brew ${i}"
			
				brew uninstall ${i}
			fi
		done
	fi
}

function uninstall_brewCasks (){
	local installedCasks=""
	
	if hash brew 2>/dev/null; then
		. "_echoMsg.sh" ""
	
		declare -a removeThis_a
	
		removeThis_a[0]="filebot"
		removeThis_a[1]="java"
	
		installedCasks=$(brew cask list)
																								# brew, remove caskroom/cask/brew-cask if in place
		for i in "${removeThis_a[@]}"; do
			if [[ ${installedCasks} == *"${i}"* ]]; then
				. "_echoMsg.sh" "Removing brew-cask ${i}"
			
				brew cask uninstall ${i}
			fi
		done
	fi
}

function uninstall_rubyGems () {
	local installedGems=""
	
	if hash gem 2>/dev/null; then
		. "_echoMsg.sh" ""
	
		declare -a removeThis_a
	
		removeThis_a[0]="video_transcoding"	
																								# ruby, remove gems if in place
		installedGems=$(gem list)
	
		for i in "${removeThis_a[@]}"; do
			if [[ ${installedGems} == *"${i}"* ]]; then
				. "_echoMsg.sh" "Removing gem ${i}"
			
				sudo gem uninstall ${i}
			fi
		done
	
		if [[ ${installedBrews} == *"ruby"* ]]; then
			. "_echoMsg.sh" "Removing brew ruby"
		
			brew rm ruby
		fi
	fi
}

function install_brewPkgs () {
	local installedBrews=""
	local installerActive=""
	local xcodePID=""
	
	installerActive="Install Command Line Developer Tools"
	xcodePID=$(pgrep "${installerActive}")

	if [[ "${xcodeInstall}" == "true" ]]; then
		if [[ -n "${xcodePID}" ]]; then
			. "_echoMsg.sh" ""
			. "_echoMsg.sh" "Waiting for Xcode Command Line Tools installation to complete..."
		
			while [[ -n "${xcodePID}" ]]; do
				sleep 0.5
				xcodePID=$(pgrep "${installerActive}")
			done
		fi
	fi
		
	. "_echoMsg.sh" ""
																							# Homebrew - install if not in place
	if ! command -v brew > /dev/null; then
		ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
	fi
	
	declare -a installThis_a
	
	installThis_a[0]="ruby"
	installThis_a[1]="atomicparsley"
	installThis_a[2]="ffmpeg"
	installThis_a[3]="mkvtoolnix"
	installThis_a[4]="mp4v2"
	installThis_a[5]="mpv"
	installThis_a[6]="rsync"
	installThis_a[7]="tag"
	installThis_a[8]="terminal-notifier"
	installThis_a[9]="handbrake"	
	
	installedBrews=$(brew list)
																							# brew, install packages
	for i in "${installThis_a[@]}"; do
		if [[ ${installedBrews} != *"${i}"* ]]; then			
			. "_echoMsg.sh" "Installing brew ${i}"
			
			if [[ "${i}" != *"rsync"* ]]; then
				brew install ${i}
			else
				brew tap homebrew/dupes
				brew install rsync
			fi
		fi
	done
}

function install_brewCasks () {
	local installedCasks=""
	
	declare -a installThis_a
	
	installThis_a[0]="java"
	installThis_a[1]="filebot"
	
	installedCasks=$(brew cask list)
																							# brew, install caskroom/cask/brew-cask
	for i in "${installThis_a[@]}"; do
		if [[ ${installedCasks} != *"${i}"* || "${i}" == *"java"* ]]; then
			. "_echoMsg.sh" "Installing brew-cask ${i}"
			
			brew cask install ${i}
		fi
	done
}

function install_rubyGems () {
	local installedGems=""
	
	. "_echoMsg.sh" ""
	
	declare -a installThis_a
	
	installThis_a[0]="video_transcoding"
																							# ruby, install gems
	installedGems=$(gem list)
	
	for i in "${installThis_a[@]}"; do
		if [[ ${installedGems} != *"${i}"* ]]; then
			. "_echoMsg.sh" "Installing gem ${i}"
			
			sudo gem install "${i}"
		fi
	done
}

function array_Contains () {
	# ${1}: array to search
	# ${2}: search term
	# Returns: array index if found
	
    local array=""
    local seeking=""
    local loopCounter=0
	local returnIndex=-1
	
	array="$1[@]"
    seeking="${2}"
	
    for element in "${!array}"; do
        if [[ "${element}" == *"${seeking}"* ]]; then
			returnIndex=${loopCounter}
            break
        fi
		((loopCounter++))
    done

    echo ${returnIndex}
}

function update_MKV () {
	local confPath="${LIBDIR}/MakeMKV/settings.conf"
	local replaceValue=""
	
	confPath="${LIBDIR}/MakeMKV/settings.conf"
	
	if [[ -e "${confPath}" ]]; then
		ingestPath=$(. "_aliasPath.sh" "${SUPPORTDIR}/Transcode/Transcode alias")"/Convert"	# get the path to /Transcode/Convert from the alias left behind by Video Transcode Setup Assistant	
		
		declare -a confArray_a

		i=0
		while IFS='' read -r lineData || [[ -n "${lineData}" ]]; do							# read in the preferences from the conf file
		    confArray_a[i]="${lineData}"
		    ((++i))
		done < "${confPath}"
		
		foundIndex=$(array_Contains confArray_a "app_DestinationDir")						# find the ingest path in the conf file
		
		if [[ "${foundIndex}" -ne "-1" ]]; then
			replaceValue="\"${ingestPath}\""												# replace the old ingest path with the new ingest path
			confArray_a[${foundIndex}]="app_DestinationDir == ${replaceValue}"				# update the array
			
			rm -f "${confPath}"																# remove the old conf file
			printf '%s\n' "${confArray_a[@]}" >> "${confPath}"								# create the new conf file
			
			. "_echoMsg.sh" "Updated MakeMKV plist"
		fi
	fi
}

function setup_Complete () {
	local scriptDir=""
	local icnsPath=""
	
	scriptDir="$(cd "$(dirname "$0")" && pwd)"
	icnsPath="${scriptDir}/AutomatorApplet.icns"
	
	. "_echoMsg.sh" "Transcode setup complete" ""
	
cat << EOF | osascript -l AppleScript > /dev/null
set iconPath to "$icnsPath" as string
set posixPath to POSIX path of iconPath
set hfsPath to POSIX file posixPath

display dialog "Setup Complete!" buttons {"OK"} default button "OK" with title "Transcode Setup Assistant" with icon file hfsPath
EOF

	Safari "http://www.videolan.org/index.html"
	Safari "http://www.makemkv.com/download/"
}

function Safari () {
																							# will open a New Safari window with argument 1.
osascript << EOD
tell application "Safari" to make new document with properties {URL:"$1"}
return
EOD
}

function clean_Up () {
	echo
	echo $'\e[1m\e[92mThis window can now be closed.\e[0m'
	echo
}

function __main__ () {
	echo ""
	echo "========================================================================="
	echo "Transcode Setup Completion"
	echo ""
	
	install_Scripts
	
	install_Tools
	
	uninstall_brewPkgs
	uninstall_brewCasks
	uninstall_rubyGems
	
	install_brewPkgs
	install_brewCasks
	install_rubyGems
	
	create_Plists
	
	update_MKV
	
	setup_Complete
}


#----------------------------------------------------------MAIN----------------------------------------------------------------
																							# Execute
trap clean_Up INT TERM EXIT																	# always run clean_Up regardless of how the script terminates
trap "exit" INT																				# trap user cancelling
trap '. "_ifError.sh" ${LINENO} $?' ERR														# trap errors
printf '\e[8;24;130t'																		# set the Terminal window size to 148x24
echo -n -e "\033]0;Transcode Setup	\007"													# set the Terminal window title
printf "\033c"																				# clear the Terminal screen

define_Constants

__main__

exit 0